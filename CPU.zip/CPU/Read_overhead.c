#include <mach/mach_time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#define BUFFER_SIZE 4096    // Standard page size
#define NUM_ITERATIONS 1000 // Number of reads to perform

int main() {
    // Convert to nanoseconds
    mach_timebase_info_data_t timebase;
    mach_timebase_info(&timebase);
    double nanos_per_tick = (double)timebase.numer / timebase.denom;
    
    // Create a test file and write some data
    const char* filename = "test_file.txt";
    int fd = open(filename, O_CREAT | O_RDWR, 0644);
    if (fd == -1) {
        perror("Error creating file");
        return 1;
    }
    
    // Write some data to the file
    char write_buffer[BUFFER_SIZE];
    for (int i = 0; i < BUFFER_SIZE; i++) {
        write_buffer[i] = 'A';
    }
    write(fd, write_buffer, BUFFER_SIZE);
    close(fd);
    
    // Measure read overhead
    char read_buffer[BUFFER_SIZE];
    uint64_t total_time = 0;
    
    // Open file for reading
    fd = open(filename, O_RDONLY);
    if (fd == -1) {
        perror("Error opening file for reading");
        return 1;
    }
    
    // Perform multiple reads and measure time
    for (int i = 0; i < NUM_ITERATIONS; i++) {
        // Reset file pointer to beginning for each iteration
        lseek(fd, 0, SEEK_SET);
        
        uint64_t start = mach_absolute_time();
        ssize_t bytes_read = read(fd, read_buffer, BUFFER_SIZE);
        uint64_t end = mach_absolute_time();
        
        if (bytes_read == -1) {
            perror("Error reading file");
            close(fd);
            return 1;
        }
        
        total_time += (end - start);
    }
    
    close(fd);
    
    // Calculate average overhead
    double avg_read_overhead_ns = (total_time * nanos_per_tick) / NUM_ITERATIONS;
    
    // Print results
    printf("File read measurements:\n");
    printf("Buffer size: %d bytes\n", BUFFER_SIZE);
    printf("Number of iterations: %d\n", NUM_ITERATIONS);
    printf("Average read overhead: %.2f nanoseconds\n", avg_read_overhead_ns);
    printf("Average read overhead: %.2f microseconds\n", avg_read_overhead_ns / 1000.0);
    
    // Clean up test file
    unlink(filename);
    
    return 0;
}